package Boundary;
import java.io.*;
import java.util.*;

import com.sun.org.apache.xalan.internal.xsltc.compiler.Pattern;
import com.sun.org.apache.xerces.internal.impl.xs.identity.Selector.Matcher;

import domain.WineRecord;
import domain.SellRecord;
import Control.AddWineRecordControl;
import Control.StockRecordControl;
import Control.OrderControl;
import Control.BillListControl;

public class SysConsole {
       
	   private static final String TITLE = "============�����݌ɊǗ��V�X�e��============";
	   private static final String ORDER = "1.����";
       private static final String ADD = "2.����";
       private static final String STOCK = "3.�݌�";
       private static final String BILL = "4.����";
       private static final String QUIT = "5.�I��";
       private static final String MESSAGE1 = "���j���[�ԍ���I�����Ă�������:";
       private static final String MESSAGE2 = "���j���[�ԍ����ԈႢ�܂����B�������I�����Ă�������:";
       private static final String MESSAGE3 = "�������Ă�������:[name wine1Name wine1number wine2Name wine2number...]";
       private static final String MESSAGE4 = "���׏�����͂��Ă�������[wine1Name  wine1number wine2Name wine2number...]";
       private static final String MESSAGE5 = "�ڋq������͂��Ă�������";
       private static final String MESSAGE6 = "�݌ɏ��";
       private static final String MESSAGE7 = "���׏�񂪐������Ȃ��ł��B";
       private static final String MESSAGE9 = "������񂪐������Ȃ��ł��B";
       private static final String MESSAGE10 = "������񂪐������Ȃ��ł��B�{���͐����œ��͂���Ă��܂���";
       private static final String MESSAGE11 = "���׏�񂪐������Ȃ��ł��B�{���͐����œ��͂���Ă��܂���";
       private static final String MESSAGE12 = "�Y���ڋq�̋L�^���Ȃ�";
       private static final String CNUMBER_PATTERN = "^[0-9]*[1-9][0-9]*$";
       
       public void outputMenu(){
    	   
    	   System.out.println(TITLE);
    	   System.out.println(ORDER);
    	   System.out.println(ADD);
    	   System.out.println(STOCK);
    	   System.out.println(BILL);
    	   System.out.println(MESSAGE1);
    	   
       }
       public void inputMenu(int input) throws IOException{
    	   
    	   switch(input){
    		   case 1: orderSubSys();break;
    		   case 2: addSubSys();break;
    		   case 3: stockSubSys();break; 
    		   case 4: billSubSys();break;
    		 
    		   default: {
    			   System.out.println(MESSAGE2); 
    			  
    		   }
    	   }
    	   
       }
       
       public void orderSubSys() throws IOException{
    	   
    	   System.out.println(MESSAGE3);   
    	   Scanner in=new Scanner(System.in);
   	       String orderInput = in.nextLine();
   	       String guestName;
   	       boolean numFlag = true;
   	       boolean countFlag = true;
   	       List<WineRecord> ls = new ArrayList<WineRecord>();
   	       String[] orderStr = null;
   	       orderStr = orderInput.split(" ");
   	       for(int i=2;i<orderStr.length;i=i+2){
   	    	numFlag = orderStr[i].matches(CNUMBER_PATTERN);
   	    	if(numFlag == false){
   	    		numFlag = false;
   	    		break;
   	    	}
   	       }
   	      
   	       if((orderStr.length-1)%2 !=0){
   	    	countFlag = false;
   	       }
   	       if(countFlag == false){
   	    	
   	    	System.out.println(MESSAGE9);  
   	    	
   	    	reDisplay();
   	    	countFlag = false;
   	    	   
   	       }
   	       if(numFlag == false){
   	    	
   	    	System.out.println(MESSAGE10);  
   	    	orderStr = new String[]{""};
   	    	reDisplay();
   	    	numFlag = false;
   	    	
   	       }
   	       else{
   	       
   	       guestName = orderStr[0];
   	       for(int i=1;i<orderStr.length-1;i=i+2){
   	    	WineRecord wr = new WineRecord();
   	    	wr.setWineName(orderStr[i]);
   	    	wr.setWineNum(Integer.parseInt(orderStr[i+1]));
   	    	ls.add(wr);  
   	    	
   	    	   
   	       }
   	       
   	       OrderControl oc = new OrderControl();
	       oc.orderProcess(guestName, ls);
	       System.out.println("\n"); 
   	       }
       }
       
       public void addSubSys() throws IOException{
    	   List<WineRecord> ls = new ArrayList<WineRecord>();
    	   StockRecordControl sC = new StockRecordControl();
    	   List<WineRecord> oldls = sC.getStockRecord();
    	   
    	   boolean numFlag = true;
    	   boolean countFlag = true;
    	   boolean addFlag = true;
    	   int i,j;
    	   System.out.println(MESSAGE4); 
    	   Scanner in=new Scanner(System.in);
   	       String wineRecord = in.nextLine();
   	       String[] wineStr;
   	       wineStr = wineRecord.split(" ");
   	       for(i=1;i<wineStr.length;i=i+2){
   	    	numFlag = checkNum(wineStr[i]);
   	    	if(numFlag == false){
   	    		numFlag = false;
   	    		break;
   	    	}
   	       }
   	       if(wineStr.length%2!=0){
   	    	countFlag = false;
   	       }
   	       if(countFlag == false){
   	    	countFlag = false;  
   	    	System.out.println(MESSAGE7);   
   	    	reDisplay();
   	       }
   	       if(numFlag == false){
   	    	System.out.println(MESSAGE11);   
   	    	reDisplay();
   	       }
   	       else{
	   	       for(i=0;i<wineStr.length-1;i=i+2){
	   	    	  
	   	    	   for(j=0;j<oldls.size();j++){
	   	    		  if(wineStr[i].equals(oldls.get(j).getWineName())){
	   	    			addFlag = false; 
	   	    			oldls.get(j).setWineNum(Integer.parseInt(wineStr[i+1])+oldls.get(j).getWineNum());  
	   	    		  }
	   	    	   }
	   	    	   if(addFlag == true){
	   	    		WineRecord wr = new WineRecord();
	   	    		wr.setWineName(wineStr[i]);
	   	    		wr.setWineNum(Integer.parseInt(wineStr[i+1]));
	   	    		oldls.add(wr);
	   	    	   }
	   	    	   else{
	   	    		addFlag = true;
	   	    		   
	   	    	   }
	   	    	  
	   	       }
	   	       AddWineRecordControl ad = new AddWineRecordControl();
	   	       ad.setWineRecord(oldls);
	   	 
	   	       
   	       }
   	       
       }
       
       public void stockSubSys() throws IOException{
    	   List<WineRecord> ls = new ArrayList<WineRecord>();
    	   System.out.println(MESSAGE6);
    	   StockRecordControl  sc=new StockRecordControl();
    	   ls = sc.getStockRecord();
    	   for(int i=0;i<ls.size();i++){
    		   System.out.println(ls.get(i).getWineName()+" "+ls.get(i).getWineNum());
    	   }
    	   
       }
       
       public void billSubSys() throws IOException{
    	   System.out.println(MESSAGE5);
    	   BillListControl bc = new BillListControl();
    	   List<SellRecord> lsGuestBillRec = new ArrayList<SellRecord>();
    	   Scanner in=new Scanner(System.in);
   	       String guestName = in.nextLine();
   	       lsGuestBillRec = bc.getGuestBillRecord(guestName);
   	    
   	       if(lsGuestBillRec.size()<1){
   	    	   
   	    	System.out.println(MESSAGE12);
   	       }
   	       else{
   	    	   
   	    	for(int i=0;i<lsGuestBillRec.size();i++){
   	    		System.out.print("No."+lsGuestBillRec.get(i).getSellNum()+" ");
   	    		for(int j=0;j<lsGuestBillRec.get(i).getListRecord().size();j++){
     		   System.out.print(lsGuestBillRec.get(i).getListRecord().get(j).getWineName()
     				   +" "+lsGuestBillRec.get(i).getListRecord().get(j).getWineNum()+" ");
   	    		}
   	    		System.out.print("\n");
   	    	   
   	       }
   	       }
       }
       
       
       public boolean checkNum(String input){
    	   
    	   boolean rtnFlag;
    	   rtnFlag = input.matches(CNUMBER_PATTERN);
    	   return rtnFlag;
       }
       
      public void menuSelect(String input) throws IOException{
    	 
    	  boolean flag=true;
    	  int menuNo;
    	  if(checkNum(input)){
  			menuNo = Integer.parseInt(input);
  			while(flag){			
  				  inputMenu(menuNo);
  				  outputMenu();
  				  Scanner in=new Scanner(System.in);
  				  String inp = in.next();
  				  menuSelect(inp);
  				  flag = false;
  	  			
  		}
  		}
  		else{
  			System.out.println("�����ԍ�����͂��Ă�������");
  			outputMenu();
  			Scanner in=new Scanner(System.in);
			 String inp = in.next();
  			
  			menuSelect(inp);
  			
  		}
    	  
      }
      
      public void reDisplay() throws IOException{
    	  
    	outputMenu();
  		Scanner in=new Scanner(System.in);
  		String input = in.next().toString();
   	    menuSelect(input);
      }
}
