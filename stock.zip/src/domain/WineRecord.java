package domain;

public class WineRecord {
   
	private String wineName;
	public String getWineName() {
		return wineName;
	}
	public void setWineName(String wineName) {
		this.wineName = wineName;
	}
	public int getWineNum() {
		return wineNum;
	}
	public void setWineNum(int wineNum) {
		this.wineNum = wineNum;
	}
	private int wineNum;
	
	
}
